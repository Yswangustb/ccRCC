#读取CellRanger部分矩阵文件
Data <- read.table(matrix.csv)

#创建SeuratObject
data <- CreateSeuratObject(counts = Data)

#计算线粒体比例
data[["percent.mt"]] <- PercentageFeatureSet(data, features=mt_genes)

#数据归一化
data <- NormalizeData(data, normalization.method = method)

#分析高变基因
data <- FindVariableFeatures(data, selection.method = method, nfeatures = feature)

#多样本整合
Rumen.anchors <- FindIntegrationAnchors(object.list = list, dims = 1:pca)
Rumen.integrated <- IntegrateData(anchorset = Rumen.anchors, dims = 1:pca)

#降维
Rumen.integrated <- ScaleData(Rumen.integrated)
Rumen.integrated <- RunPCA(Rumen.integrated, npcs = pca)
Rumen.integrated <- RunUMAP(Rumen.integrated, dims = 1:pca)
Rumen.integrated <- RunTSNE(Rumen.integrated, dims = 1:pca)

#画Umap图
umap <- DimPlot(Rumen.integrated, reduction = "umap")

#画Tsne图
tsne <- DimPlot(Rumen.integrated, reduction = "tsne")

#聚类
Rumen.integrated <- FindNeighbors(Rumen.integrated, dims = 1:pca)
Rumen.integrated <- FindClusters(Rumen.integrated, resolution = resolutions)

#保存rds
saveRDS(Rumen.integrated)

#差异
Rumen.integrated.markers <- FindAllMarkers(Rumen.integrated)

#画热图
DoHeatmap(Rumen.integrated, features = feature) 

#画气泡图
DotPlot(Rumen.integrated, features = feature)

#读取聚类结果
ctrl <- readRDS(seurat.rds)

#SingleR注释
test <- as.SingleCellExperiment(ctrl)
Anno <- SingleR(test = test,ref = BL, method = method)

#画Umap图
test@meta.data$labels <- Anno$labels
DimPlot(test, reduction = "umap")

#画Tsne图
DimPlot(test, reduction = "tsne")

#画热图
DoHeatmap(test, features = feature) 

#画气泡图
DotPlot(test, features = feature)

# 使用CellCycleScoring函数计算细胞周期评分 
marrow <- CellCycleScoring(marrow, s.features = s.genes, g2m.features = g2m.genes, set.ident = TRUE) 