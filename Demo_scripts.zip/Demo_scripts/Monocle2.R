#读取rds数据
data <- readRDS(infile.rds)

#构建S4对象
HSMM <- newCellDataSet(count, phenoData = pd, featureData = fd)

#估计size factors 和 dispersions
HSMM <- estimateSizeFactors(HSMM)
HSMM <- estimateDispersions(HSMM)

#过滤低质量基因
HSMM <- detectGenes(HSMM, min_expr = mins)

#选择基因
diff_test_res <- differentialGeneTest(HSMM[expressed_genes,], fullModelFormulaStr = "~ Clusters")
HSMM <- setOrderingFilter(HSMM, ordering_gene)

#降维排序
HSMM <- reduceDimension(HSMM, max_components = max_components, method = method)
HSMM <- orderCells(HSMM)

#可视化
plot_cell_trajectory(HSMM, color_by = "Cluster") 
plot_cell_trajectory(HSMM, color_by = "Sample") 
plot_cell_trajectory(HSMM, color_by = "Pseudotime") 

