# -*- coding: utf-8 -*-
"""
Created on Sun Feb 19 09:34:27 2023

@author: 25821
"""

from logging import Logger
import os
from typing import Tuple
import pandas as pd
import numpy as np
import torch
import joblib
import matplotlib.pyplot as plt

from .run_training import run_training,get_xgboost_feature,predict_feature
from chemprop.args import TrainArgs
from chemprop.data.utils import get_task_names
from chemprop.utils import makedirs
from morgan_feature import get_morgan_feature,xgboost_cv,xgb_cv_more,xgb_regre_cv,xgb_regre_more,svm_knn_rf_class_cv,svm_knn_rf_regre,svm_knn_rf_class_more,svm_knn_rf_regre_more

def Find_optimal_cutoff(TPR,FPR,threshold):
    y=TPR-FPR
    Youden_index=np.argmax(y)
    optimal_threshold=threshold[Youden_index]
    point=[FPR[Youden_index],TPR[Youden_index]]
    return optimal_threshold,point

def save_roccurve(args:TrainArgs,fig,fpr,tpr,thresholds,xgb_auc,num):
    optimal_th,optimal_point=Find_optimal_cutoff(tpr,fpr,thresholds)
        
    #画出此类ROC曲线
    plt.plot(fpr, tpr, color='aqua',
             lw=2, label='%s(area = %0.10f,optimal threshold=%0.2f)' % (args.protein,xgb_auc,optimal_th))
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.plot(optimal_point[0],optimal_point[1],marker='o',color='r')
    # plt.text(optimal_point[0][0],optimal_point[0][1],f'Threshold:{optimal_th:.2f}')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'ROC Curve of {args.protein}')
    plt.legend(loc="lower right")
    if not os.path.exists(os.path.join(args.save_dir,f'fold_{num}','Loss')):
        os.makedirs(os.path.join(args.save_dir,f'fold_{num}','Loss'))
    plt.savefig(os.path.join(args.save_dir,f'fold_{num}','Loss',args.protein+f'_roc_{num}.jpg'))
#绘制损失曲线并保存
def save_losscurve(args: TrainArgs,fig,df,num):
    epoch=df['epoch']
    train_loss=df['train_loss_list']
    val_loss=df['val_loss']
    plt.plot(epoch,train_loss,color='navy', label='Train Loss')
    plt.plot(epoch,val_loss, color='aqua', label='Val Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title(f'GGNN Loss Curve of {args.protein}')
    plt.legend(loc="upper right")
    if not os.path.exists(os.path.join(args.save_dir,f'fold_{num}','Loss')):
        os.makedirs(os.path.join(args.save_dir,f'fold_{num}','Loss'))
    plt.savefig(os.path.join(args.save_dir,f'fold_{num}','Loss',args.protein+f'_loss_{num}.jpg'))

def cross_validate(args: TrainArgs, logger: Logger = None) -> Tuple[float, float]:
    """k-fold cross validation
    网格搜索参数寻优，评分方式为交叉验证评分,最后保存网格搜索表格"""
    info = logger.info if logger is not None else print

    # Initialize relevant variables
    init_seed = args.seed
    save_dir = args.save_dir
    args.model_dirname='0'
    # Run training on different random seeds for each fold
    dmpnn_scores = []
    scores_df = pd.DataFrame()
    #五折交叉验证，每一次是一折内进行交叉验证
    for fold_num in range(args.num_folds):
        print(f'进行{args.num_folds}折交叉验证')
        if args.dataset_type == 'classification':
            args.data_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/train.csv'
            args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/test.csv'
            args.separate_val_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/val.csv'
            
            # args.data_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/train.csv'
            # #args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c'+'/val.csv'
            # args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/test.csv'
        elif args.dataset_type == 'regression':
            args.data_path = 'molnet_benchmark/molnet_random_'+args.protein+'_r'+'/train.csv'
           # args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_r'+'/val.csv'
            args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_r'+'/test.csv'
        info(f'Fold {fold_num}')
        args.seed = init_seed + fold_num
        args.save_dir = os.path.join(save_dir, f'fold_{fold_num}')
        makedirs(args.save_dir)
        model_scores,model,scaler,df,fpr,tpr,thresholds,myauc,dfresults = run_training(args, logger)
        #绘制损失曲线
        fig1=plt.figure()
        save_losscurve(TrainArgs().parse_args(),fig1,df,fold_num)
        # #绘制dmpnn的roc曲线
        # fig2=plt.figure()
        # save_roccurve(TrainArgs().parse_args(),fig1,fpr,tpr,thresholds,myauc,fold_num)
        
        
        #损失数据保存到csv
        if args.loss_save:
            df.to_csv(os.path.join(args.save_dir,'Loss',args.protein+f'_loss_{fold_num}.csv'),index=None)
            # dfresults.to_csv(os.path.join(args.save_dir,'Loss',args.protein+f'_auc_{fold_num}.csv'),index=None)
        
        dmpnn_scores.append(model_scores)
        train_target, train_feature, val_target, val_feature, test_target, test_feature,train_smiles,val_smiles,test_smiles,test_preds = get_xgboost_feature(args, logger,model)
        train_target = pd.DataFrame(train_target)
        train_feature = pd.DataFrame(train_feature)
        val_target = pd.DataFrame(val_target)
        val_feature = pd.DataFrame(val_feature)
        test_target = pd.DataFrame(test_target)
        test_feature = pd.DataFrame(test_feature)
        train_morgan_feature = get_morgan_feature(train_smiles)
        val_morgan_feature = get_morgan_feature(val_smiles)
        test_morgan_feature = get_morgan_feature(test_smiles)
        if args.dataset_type == 'classification':
            if test_target.shape[1]==1:
                scores = xgboost_cv(args,train_feature, train_target,val_feature, val_target,test_feature,test_target,
                                        train_morgan_feature,val_morgan_feature,test_morgan_feature,test_preds)
            else:
                scores = xgb_cv_more(max_depth_numbers,learning_rate_numbers,min_child_weight_numbers,
                                        train_feature, train_target,val_feature, val_target,test_feature,test_target,
                                        train_morgan_feature,val_morgan_feature,test_morgan_feature,test_preds)
            scores_df = pd.concat([scores_df,scores])
        
        elif args.dataset_type == 'regression':
            if test_target.shape[1]==1:
                scores = xgb_regre_cv(max_depth_numbers, learning_rate_numbers, min_child_weight_numbers,
                                         train_feature, train_target, val_feature, val_target, test_feature, test_target,
                                         train_morgan_feature, val_morgan_feature, test_morgan_feature, test_preds, scaler)
            else:
                scores = xgb_regre_more(max_depth_numbers, learning_rate_numbers, min_child_weight_numbers,
                                         train_feature, train_target, val_feature, val_target, test_feature, test_target,
                                         train_morgan_feature, val_morgan_feature, test_morgan_feature, test_preds, scaler)
            scores_df = pd.concat([scores_df,scores])
    #存详细表scores_df
    scores_df.to_csv(os.path.join(f'delaney_{args.protein}_c',f'{args.protein}_allscores.csv'))
    # df_groupby_auc = scores_df.groupby(by=['type', 'n_estimators','max_depth','scale_pos_weight','learning_rate','min_child_weight'])['AUC'].agg(
    #     [('auc_mean',np.mean),
    #       ('auc_sd',np.std)
    #         ])
    # df_groupby_ner = scores_df.groupby(by=['type', 'n_estimators','max_depth','scale_pos_weight','learning_rate','min_child_weight'])['NER'].agg(
    #     [('ner_mean',np.mean),
    #       ('ner_sd',np.std)
    #         ])
    # df_groupby=pd.merge(df_groupby_auc,df_groupby_ner,on=['type', 'n_estimators','max_depth','scale_pos_weight','learning_rate','min_child_weight'],how='inner')
    # df_groupby.to_csv(f'result_csv/{args.protein}/{args.protein}_finalscores.csv')

    return model



def cross_validate_mechine(args: TrainArgs, logger: Logger = None):
    """k-fold cross validation"""
    info = logger.info if logger is not None else print

    # Initialize relevant variables
    init_seed = args.seed
    args.save_dir=f'delaney_{args.protein}_c'
    save_dir = args.save_dir
    args.model_dirname='ml'

    # Run training on different random seeds for each fold
    dmpnn_scores = []
    scores_df = pd.DataFrame()
    for fold_num in range(args.num_folds):
        if args.dataset_type == 'classification':
            args.data_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/train.csv'
            args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/test.csv'
            args.separate_val_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/val.csv'
        elif args.dataset_type == 'regression':
            args.data_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/train.csv'
            args.separate_test_path = 'molnet_benchmark/molnet_random_'+args.protein+'_c/seed'+str(fold_num)+'/test.csv'
            #args.separate_val_path = 'molnet_benchmark/molnet_random_'+args.protein+'_r/seed'+str(fold_num+1)+'/test.csv'
        info(f'Fold {fold_num}')
        args.seed = init_seed + fold_num
        args.save_dir = os.path.join(save_dir, f'fold_{fold_num}')
        makedirs(args.save_dir)
        model_scores,model,scaler,df,fpr,tpr,thresholds,myauc,dfresults= run_training(args, logger)
        if args.loss_save:
            if not os.path.exists(os.path.join(args.save_dir,'Loss_ml')):
                os.makedirs(os.path.join(args.save_dir,'Loss_ml'))
            df.to_csv(os.path.join(args.save_dir,'Loss_ml',f'{args.protein}_loss_{fold_num}.csv'),index=None)
            dfresults.to_csv(os.path.join(args.save_dir,'Loss_ml',args.protein+f'_auc_{fold_num}.csv'),index=None)

        dmpnn_scores.append(model_scores)
        train_target, train_feature, val_target, val_feature, test_target, test_feature,train_smiles,val_smiles,test_smiles,test_preds = get_xgboost_feature(args, logger,model)
        train_target = pd.DataFrame(train_target)
        train_feature = pd.DataFrame(train_feature)
        val_target = pd.DataFrame(val_target)
        val_feature = pd.DataFrame(val_feature)
        test_target = pd.DataFrame(test_target)
        test_feature = pd.DataFrame(test_feature)
        train_morgan_feature = get_morgan_feature(train_smiles)
        val_morgan_feature = get_morgan_feature(val_smiles)
        test_morgan_feature = get_morgan_feature(test_smiles)
        if args.dataset_type == 'classification':
            if test_target.shape[1]==1:
                scores = svm_knn_rf_class_cv(args,train_feature, train_target,val_feature, val_target,test_feature,test_target,
                     train_morgan_feature,val_morgan_feature,test_morgan_feature,test_preds)
            else:
                scores = svm_knn_rf_class_more(train_feature, train_target,val_feature, val_target,test_feature,test_target,
                     train_morgan_feature,val_morgan_feature,test_morgan_feature,test_preds)
            scores_df = pd.concat([scores_df,scores])
        elif args.dataset_type == 'regression':
            if test_target.shape[1]==1:
                scores = svm_knn_rf_regre(train_feature, train_target,val_feature, val_target,test_feature,test_target,
                     train_morgan_feature,val_morgan_feature,test_morgan_feature,test_preds)
            else:
                scores = svm_knn_rf_regre_more(train_feature, train_target,val_feature, val_target,test_feature,test_target,
                     train_morgan_feature,val_morgan_feature,test_morgan_feature,test_preds)
            scores_df = pd.concat([scores_df,scores])
    scores_df.to_csv(os.path.join(f'delaney_{args.protein}_c',f'{args.protein}_mechine_scores.csv'))


