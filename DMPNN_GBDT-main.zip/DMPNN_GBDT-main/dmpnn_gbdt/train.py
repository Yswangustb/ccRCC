"""Trains a model on a dataset."""
import os,warnings
warnings.filterwarnings('ignore',category=FutureWarning)
warnings.filterwarnings('ignore',category=UserWarning)
# os.environ['CUDA_VISIBLE_DEVICES'] = '1'

from chemprop.args import TrainArgs
from chemprop.train import cross_validate,cross_validate_mechine
from chemprop.utils import create_logger


if __name__ == '__main__':
#获取参数
    args = TrainArgs().parse_args()
#创建日志
    logger = create_logger(name='train', save_dir=args.save_dir, quiet=args.quiet)
#交叉验证
    model = cross_validate(args, logger)
    cross_validate_mechine(args, logger)


