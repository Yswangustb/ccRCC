import warnings
warnings.filterwarnings('ignore',category=FutureWarning)
warnings.filterwarnings('ignore',category=UserWarning)
import numpy as np
import torch
import argparse
import os
import pandas as pd
from sklearn.metrics import roc_curve, auc, mean_squared_error,precision_score,precision_recall_curve,r2_score,mean_absolute_error
from tensorboardX import SummaryWriter
from torch import optim, nn
from data_deal import decrease_learning_rate
from gcn_model.gcn_model import GCN
from gcn_model.gcn_xgboost_scores import get_feature
from gcn_model.gcn_training import training,evaluate,training_classing,evaluate_classion,evaluate_test_scros
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from load_data_batch import loadInputs_train,loadInputs_val,loadInputs_test,ToxicDataset,load_data,ZW6,get_mol,get_morgan_feature,loadInputs_feature_smiles
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingClassifier
from copy import deepcopy
from sklearn.metrics import confusion_matrix,accuracy_score,f1_score
import pickle

def get_evaluate(test_target,pre_pro):
    fpr, tpr, threshold = roc_curve(test_target, pre_pro)
    rocdata={'fpr':fpr,'tpr':tpr,'threshold':threshold}    
    AUC = auc(fpr, tpr)
    pre_pro = [1 if i > 0.5 else 0 for i in pre_pro]
    tn, fp, fn, tp = confusion_matrix(test_target, pre_pro).ravel()
    Sn = tp / (tp + fn)
    Sp = tn / (tn + fp)
    acc = accuracy_score(test_target, pre_pro)
    ner=(Sn+Sp)/2
    f1=f1_score(test_target, pre_pro)
    # mcc=(tp*tn-fp*fn)/(sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
        
    return tn,fp,fn,tp,acc,AUC,ner,f1,rocdata
def mechine_regression(X_train,y_train,X_val, y_val,X_test,y_test):
    scores = []
    if y_test.shape[-1]==1:
        rf = RandomForestRegressor()
        rf.fit(X_train, y_train)
        y_pred = rf.predict(X_test)
        y_test = y_test.astype('float')
        MSE = mean_squared_error(y_test,y_pred)
        RMSE = MSE ** 0.5
        type = 'GCN+rf'
        scores.append([type,RMSE])
        clf = svm.SVR(C=0.8, cache_size=200, kernel='rbf', degree=3, epsilon=0.2)
        clf.fit(X_train, y_train)
        y_pre = clf.predict(X_test)
        MSE = mean_squared_error(y_test, y_pre)
        RMSE = MSE ** 0.5
        type = 'GCN+svm'
        scores.append([type, RMSE])
        knn = KNeighborsRegressor(n_neighbors=5)
        knn.fit(X_train, y_train)
        y_pre = knn.predict(X_test)
        MSE = mean_squared_error(y_test, y_pre)
        RMSE = MSE ** 0.5
        type = 'GCN+knn'
        scores.append([type, RMSE])
        scores_df = pd.DataFrame(scores)
        return scores_df
    else:
        if len(y_train.shape)==3:
            y_train = [x[0] for x in y_train]
            y_val = [x[0] for x in y_val]
            y_test = [x[0] for x in y_test]
            y_train = pd.DataFrame(y_train)
            y_val = pd.DataFrame(y_val)
            y_test = pd.DataFrame(y_test)
        rf_rmse = []
        svm_rmse = []
        knn_rmse = []
        for i in range(y_test.shape[1]):
            if float(max(y_val[i])) == 0 or float(max(y_train[i])) == 0 or float(max(y_test[i])) == 0:
                continue
            rf = RandomForestRegressor()
            rf.fit(X_train, y_train[i])
            y_pred = rf.predict(X_test)
            y_test = y_test[i].astype('float')
            MSE = mean_squared_error(y_test[i], y_pred)
            RMSE = MSE ** 0.5
            rf_rmse.append(RMSE)
        type = 'GCN+rf'
        scores.append([type, np.mean(rf_rmse)])
        for i in range(y_test.shape[1]):
            clf = svm.SVR(C=0.8, cache_size=200, kernel='rbf', degree=3, epsilon=0.2)
            clf.fit(X_train, y_train[i])
            y_pre = clf.predict(X_test)
            MSE = mean_squared_error(y_test[i], y_pre)
            RMSE = MSE ** 0.5
            type = 'GCN+svm'
            scores.append([type, RMSE])
            knn = KNeighborsRegressor(n_neighbors=5)
            knn.fit(X_train, y_train[i])
            y_pre = knn.predict(X_test)
            MSE = mean_squared_error(y_test[i], y_pre)
            RMSE = MSE ** 0.5
            svm_rmse.append([type, RMSE])
        type = 'GCN+svm'
        scores.append([type, np.mean(svm_rmse)])
        for i in range(y_test.shape[1]):
            knn = KNeighborsRegressor(n_neighbors=5)
            knn.fit(X_train, y_train[i])
            y_pre = knn.predict(X_test)
            MSE = mean_squared_error(y_test[i], y_pre)
            RMSE = MSE ** 0.5
            knn_rmse.append(RMSE)
        type = 'GCN+knn'
        scores.append([type, np.mean(knn_rmse)])
        scores_df = pd.DataFrame(scores)
        return scores_df



def mechine_classion(X_train,y_train,X_val, y_val,X_test,y_test,train_gcn_mor_feature,val_gcn_mor_feature,test_gcn_mor_feature,pkl_path,args,scores_df):
    if y_test.shape[-1]==1:
        for n_estimator in [10,50,100,300,700,1000]:
            for mmax_depth in [2,4,6,8,10]:
                for max_feature in ['sqrt','log2']:
                    for mcriterion in ['gini','entropy']:
                        rf1=RandomForestClassifier(n_estimators=n_estimator,max_depth=mmax_depth,max_features=max_feature,criterion=mcriterion,class_weight='balanced',n_jobs=-1)
                        rf1.fit(X_train, y_train)  # 使用训练集对测试集进行训练
                        pre_pro = rf1.predict_proba(X_test)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+rf'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'max_depth':mmax_depth,'max_features':max_feature,'criterion':mcriterion,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_maxdepth{mmax_depth}_maxfeature{max_feature}_criterion{mcriterion}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
                        
                        rf2=RandomForestClassifier(n_estimators=n_estimator,max_depth=mmax_depth,max_features=max_feature,criterion=mcriterion,class_weight='balanced',n_jobs=-1)
                        rf2.fit(train_gcn_mor_feature,y_train)  # 使用训练集对测试集进行训练
                        pre_pro = rf2.predict_proba(test_gcn_mor_feature)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+moragn+rf'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'max_depth':mmax_depth,'max_features':max_feature,'criterion':mcriterion,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_maxdepth{mmax_depth}_maxfeature{max_feature}_criterion{mcriterion}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
            
        for n_estimator in [10,50,100,300,700,1000]:
            for mmin_samples_split in [2,3,4,5]:
                for mmax_depth in [2,4,6,8,10]:
                    for max_feature in ['sqrt','log2']:
                        clf1=GradientBoostingClassifier(n_estimators=n_estimator,min_samples_split=mmin_samples_split,max_depth=mmax_depth,max_features=max_feature)
                        clf1.fit(X_train,y_train)
                        pre_pro = clf1.predict_proba(X_test)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+GBDT'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'min_samples_split':mmin_samples_split,'max_depth':mmax_depth,'max_features':max_feature,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_minsample{mmin_samples_split}_maxdepth{mmax_depth}_maxfeature{max_feature}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
                        
                        clf2=GradientBoostingClassifier(n_estimators=n_estimator,min_samples_split=mmin_samples_split,max_depth=mmax_depth,max_features=max_feature)
                        clf2.fit(train_gcn_mor_feature, y_train)
                        pre_pro = clf2.predict_proba(test_gcn_mor_feature)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+morgan+GBDT'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'min_samples_split':mmin_samples_split,'max_depth':mmax_depth,'max_features':max_feature,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_minsample{mmin_samples_split}_maxdepth{mmax_depth}_maxfeature{max_feature}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
        
        scores_df=scores_df.where((scores_df.notna()),'None')
        # scores = []
        # rf = RandomForestClassifier()
        # rf.fit(X_train, y_train)  # 使用训练集对测试集进行训练
        # y_pre = rf.predict(X_test)
        # fpr, tpr, threshold = roc_curve(y_test, y_pre)
        # AUC = auc(fpr, tpr)
        # type = 'GCN+rf'
        # scores.append([type, AUC])
        # clf = svm.SVC(C=1, kernel='rbf', degree=3, gamma='auto',
        #               coef0=0.0, shrinking=True, probability=False,
        #               tol=1e-3, cache_size=200, class_weight=None,
        #               verbose=False, max_iter=-1, decision_function_shape='ovr',
        #               random_state=None)
        # clf.fit(X_train, y_train)
        # y_pre = clf.predict(X_test)
        # fpr, tpr, threshold = roc_curve(y_test, y_pre)
        # AUC = auc(fpr, tpr)
        # type = 'GCN+svm'
        # scores.append([type, AUC])
        # clf = KNeighborsClassifier(n_neighbors=5, weights='uniform')
        # clf.fit(X_train, y_train)
        # y_pre = clf.predict(X_test)
        # fpr, tpr, threshold = roc_curve(y_test, y_pre)
        # AUC = auc(fpr, tpr)
        # type = 'GCN+rnn'
        # scores.append([type, AUC])
        # scores_df = pd.DataFrame(scores)
        return scores_df
    else:
        rf_auc = []
        svm_auc = []
        knn_auc = []
        scores = []
        if len(y_train.shape)==3:
            y_train = [x[0] for x in y_train]
            y_val = [x[0] for x in y_val]
            y_test = [x[0] for x in y_test]
            y_train = pd.DataFrame(y_train)
            y_val = pd.DataFrame(y_val)
            y_test = pd.DataFrame(y_test)
        for i in range(y_test.shape[1]):
            if float(max(y_val[i])) == 0 or float(max(y_train[i])) == 0 or float(max(y_test[i])) == 0:
                continue
            rf = RandomForestClassifier()
            rf.fit(X_train, y_train[i])  # 使用训练集对测试集进行训练
            y_pre = rf.predict(X_test)
            fpr, tpr, threshold = roc_curve([float(j) for j in y_test[i]], [float(k) for k in y_pre])
            AUC = auc(fpr, tpr)
            rf_auc.append(AUC)
        type = 'GCN+rf'
        scores.append([type, np.mean(rf_auc)])
        for i in range(y_test.shape[1]):
            clf = svm.SVC(C=1, kernel='rbf', degree=3, gamma='auto',
                          coef0=0.0, shrinking=True, probability=False,
                          tol=1e-3, cache_size=200, class_weight=None,
                          verbose=False, max_iter=-1, decision_function_shape='ovr',
                          random_state=None)
            clf.fit(X_train, y_train[i])
            y_pre = clf.predict(X_test)
            fpr, tpr, threshold = roc_curve([float(j) for j in y_test[i]], [float(k) for k in y_pre])
            AUC = auc(fpr, tpr)
            if AUC>0:
                svm_auc.append(AUC)
        type = 'GCN+svm'
        scores.append([type, np.mean(svm_auc)])
        for i in range(y_test.shape[1]):
            clf = KNeighborsClassifier(n_neighbors=5, weights='uniform')
            clf.fit(X_train, y_train[i])
            y_pre = clf.predict(X_test)
            fpr, tpr, threshold = roc_curve([float(j) for j in y_test[i]], [float(k) for k in y_pre])
            AUC = auc(fpr, tpr)
            if AUC>0:
                knn_auc.append(AUC)
        type = 'GCN+knn'
        scores.append([type, np.mean(knn_auc)])
        scores_df = pd.DataFrame(scores)
        return scores_df
def get_argv():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=200,
                        help='Number of epochs to train.')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='Initial learning rate.')
    # parser.add_argument('--folder', type=str, default="benchmark_molnet/molnet_random_CCR5_c")
    parser.add_argument('--hidden', type=int, default=512,
                        help='Number of hidden units.')
    parser.add_argument('--dropout', type=float, default=0.5,
                        help='Dropout rate (1 - keep probability).')
    parser.add_argument('--save_dir', type=str, default="loss")
    parser.add_argument('--batch_size', type=float, default=128)
    parser.add_argument('--natom', type=float, default=58)
    parser.add_argument('--nclass', type=float, default=1)
    parser.add_argument('--protein',type=str,default='CCR5')
    parser.add_argument('--type', type=str, default="classification")
    args = parser.parse_args()
    return args

def get_scores(gcn_scores,names,args,device):
    '''
    给出ggnn
    ggnn+rf/GBDT
    ggnn+morgan+rf/GBDT
    '''
    #五折交叉验证
    scores_df=pd.DataFrame()
    for i in range(5):
        if not os.path.exists(os.path.join(args.save_dir,f'fold_{i}','model_0')):
            os.makedirs(os.path.join(args.save_dir,f'fold_{i}','model_0'))
        writer = SummaryWriter(log_dir=os.path.join(args.save_dir,f'fold_{i}','model_0'))
        train_loss_list = []
        val_loss_list = []
        epoch_number = []
        #加载本折数据+参数
        args.folder=os.path.join('benchmark_molnet',f'molnet_random_{args.protein}_c')
        args.dataset = args.folder + '/seed' + str(i )
        train_smiles,val_smiles,test_smiles=load_data(args)
        feature_train,a_train,y_train,smiles_train = loadInputs_feature_smiles(args,'train')
        feature_val,a_val,y_val,smiles_val = loadInputs_feature_smiles(args,'val')
        feature_test,a_test,y_test,smiles_test = loadInputs_feature_smiles(args,'test')
        #feature_train, a_train, y_train = loadInputs_train(args)
        #feature_val, a_val, y_val = loadInputs_val(args)
        #feature_test, a_test, y_test = loadInputs_test(args)
        print(f'train的shape{feature_train.shape},{a_train.shape},{y_train.shape}')
        print(f'val的shape{feature_val.shape},{a_val.shape},{y_val.shape}')
        print(f'test的shape{feature_test.shape},{a_test.shape},{y_test.shape}')

        args.nclass = y_test.shape[-1]
        #GGNN模型创建/优化器
        names['model' + str(i)] = GCN(args.natom, args.hidden, args.nclass, args.dropout).to(device)
        optimizer = optim.Adam(names['model' + str(i)].parameters(), lr=args.lr)
        #训练/验证/测试数据集生成迭代器
        train_dataset = ToxicDataset(feature_train, a_train, y_train)
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
        val_dataset = ToxicDataset(feature_val, a_val, y_val)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
        test_dataset = ToxicDataset(feature_test, a_test, y_test)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        if args.type == 'regression':
            args.metric = 'RMSE'
            criterion = nn.MSELoss()
            for epoch in range(args.epochs):
                train_loss, train_R2, val_total_loss = training(names['model' + str(i)], train_loader, optimizer,
                                                                criterion, args)
                val_loss, val_RMSE, val_R2, _,_ = evaluate(names['model' + str(i)], val_loader, criterion, device)
                print(f'\tTrain Loss: {train_loss:.3f}%')
                print(f'\t Val. RMSE: {val_RMSE:.3f}')
                writer.add_scalar('Train/Loss', train_loss, epoch)
                writer.add_scalar('val/Loss', val_loss, epoch)
                train_loss_list.append(train_loss)
                val_loss_list.append(val_loss)
                epoch_number.append(epoch)
                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
            test_loss, test_RMSE, test_R2, _,MAE = evaluate(names['model' + str(i)], test_loader, criterion, args)
            print(f'\t test. RMSE: {test_RMSE:.3f}')
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, args.device)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, args.device)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader,args.device)
            xgb_train_feature = xgb_train_feature.cpu().numpy()
            xgb_val_feature = xgb_val_feature.cpu().numpy()
            xgb_test_feature = xgb_test_feature.cpu().numpy()
            xgb_RMSE = xgb_regression(xgb_train_feature, y_train, xgb_val_feature, y_val, xgb_test_feature, y_test)
            if args.folder =="benchmark_molnet/molnet_random_qm7_r":
                gcn_scores.append([MAE])
            else:
                gcn_scores.append([test_RMSE])
            xgb_scores.append([xgb_RMSE])
        else:
            args.metric = 'AUC'
            criterion = nn.BCEWithLogitsLoss()
            #得到损失曲线图
            best_score = 0 
            best_epoch = 0
            for epoch in range(args.epochs):
                #训练集进行训练
                train_loss, val_total_loss = training_classing(names['model' + str(i)], train_loader, optimizer,
                                                               criterion, device)
                #验证集进行验证
                val_loss, val_AUC, val_precision, val_recall = evaluate_classion(names['model' + str(i)], val_loader,
                                                                                criterion, device)
                #输出每一epoch训练验证结果
                print(f'\t Epoch:{epoch+1}__Train Loss: {train_loss:.3f}')
                print(f'\tVal AUC: {val_AUC:.3f}')
                print(f'\tVal. precision: {val_precision:.3f}')
                #loss曲线加入tensorboard
                writer.add_scalar('Train/Loss', train_loss, epoch)
                writer.add_scalar('val/Loss', val_loss, epoch)
                train_loss_list.append(train_loss)
                val_loss_list.append(val_loss)
                epoch_number.append(epoch)
                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
                # Average validation score
                # Save model checkpoint if improved validation score，如果提升验证集性能则保存model
                if val_AUC > best_score:
                    best_score, best_epoch = val_AUC, epoch
                    best_model_state = deepcopy(names['model' + str(i)].state_dict()) 
                    model_save_path=os.path.join(args.save_dir,f'fold_{i}','model_0', 'model.pt')
                    torch.save(best_model_state, model_save_path)
                    
            #绘制GGNN损失曲线
            df = pd.DataFrame({'epoch': epoch_number, 'train_loss_list': train_loss_list, 'val_loss': val_loss_list})
            if not os.path.exists(os.path.join(args.save_dir,f'fold_{i}','Loss')):
                os.makedirs(os.path.join(args.save_dir,f'fold_{i}','Loss'))
            df.to_csv(os.path.join(args.save_dir,f'fold_{i}','Loss',args.protein+f'_loss_{i}.csv'),index=None)
            fig1=plt.figure()
            save_losscurve(fig1,df,args,i)
            #测试集迭代器
            test_loader_xgb = (torch.from_numpy(np.float32(feature_test)), torch.from_numpy(np.float32(a_test)),
                               torch.from_numpy(np.float32(y_test)))
            
            #预测的时候加载在验证集上表现最好的模型
            loaded_paras = torch.load(model_save_path)
            names['model' + str(i)].load_state_dict(loaded_paras)  # 用本地已有模型来重新初始化网络权重参数
            #仅用GGNN得到的测试集指标
            test_loss,test_AUC, test_precision, test_recall ,y_predict= evaluate_test_scros(names['model' + str(i)],test_loader_xgb, criterion, device)
            print(type(y_test),type(y_predict))
            print(y_test)
            print(y_test[0])
            tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,y_predict[0])
            ml_type = 'ggnn'
            model_param={'type':ml_type,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
            pkl_path=os.path.join(args.save_dir,f'fold_{i}','model_0','test_preds')
            if not os.path.exists(pkl_path):
                os.makedirs(os.path.join(pkl_path))
            with open (os.path.join(pkl_path,f'{ml_type}.pkl'),'wb') as f:
                pickle.dump([rocdata,model_param],f)
            scores_df=scores_df.append(model_param,ignore_index=True)
                
            
            
            # fpr, tpr, threshold = roc_curve(test_target, [i[0] for i in test_preds])
            # AUC = auc(fpr, tpr)
            # pre_pro = [1 if i > 0.5 else 0 for i in [i[0] for i in test_preds]]
            # tn, fp, fn, tp = confusion_matrix(test_target, pre_pro).ravel()
            # Sn = tp / (tp + fn)
            # Sp = tn / (tn + fp)
            # acc = accuracy_score(test_target, pre_pro)
            # ner=(Sn+Sp)/2
            # f1=f1_score(test_target, pre_pro)
            # # mcc=(tp*tn-fp*fn)/(sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
            # rocdata={'fpr':fpr,'tpr':tpr,'threshold':threshold}
            # xgb_type='dmpnn'
            # model_param={'type':xgb_type,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
            # #将fpr,tpr,threshold及参数信息存为pkl

            # with open (os.path.join(pkl_path,'dmpnn.pkl'),'wb') as f:
            #     pickle.dump([rocdata,model_param],f)
            # scores_df=scores_df.append(model_param,ignore_index=True)
            
            
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            #得到GGNN输出的训练集、验证集、测试集的特征
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, args.device)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, args.device)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, args.device)
            xgb_train_feature = pd.DataFrame(xgb_train_feature.cpu().numpy())
            xgb_val_feature = pd.DataFrame(xgb_val_feature.cpu().numpy())
            xgb_test_feature =pd.DataFrame(xgb_test_feature.cpu().numpy())
            #得到morgan特征
            train_morgan_feature = get_morgan_feature(smiles_train)
            val_morgan_feature = get_morgan_feature(smiles_val)
            test_morgan_feature = get_morgan_feature(smiles_test)
            #拼接morgan特征与ggnn特征
            train_gcn_mor_feature = pd.concat([xgb_train_feature, train_morgan_feature], axis=1)
            val_gcn_mor_feature = pd.concat([xgb_val_feature, val_morgan_feature], axis=1)
            test_gcn_mor_feature = pd.concat([xgb_test_feature, test_morgan_feature], axis=1)
            train_gcn_mor_feature.columns = val_gcn_mor_feature.columns = test_gcn_mor_feature.columns = range(train_gcn_mor_feature.shape[1])  
            
            ####导出GGNN+GBDT/RF的结果
            scores_df= mechine_classion(xgb_train_feature, y_train, xgb_val_feature, y_val,xgb_test_feature, y_test,train_gcn_mor_feature,val_gcn_mor_feature,test_gcn_mor_feature,pkl_path,args,scores_df)
            # xgboost_classion(xgb_train_feature, y_train, xgb_val_feature, y_val,xgb_test_feature, y_test,i)
            # #roc曲线图
            # fig2=plt.figure()
            # save_roccurve(fig2,fpr,tpr,thresholds,xgb_auc,i,args)
            gcn_scores.append([test_AUC])
            # xgb_scores.append([xgb_auc])
    scores_df.to_csv(os.path.join(args.save_dir,f'{args.protein}_mechine_scores.csv'))

    return gcn_scores

def mechine_scores(gcn_scores,xgb_scores,names,args,device):
    for i in range(3):
        args.dataset = args.folder + '/seed' + str(i + 1)
        feature_train,a_train,y_train,smiles_train = loadInputs_feature_smiles(args,'train')
        feature_val,a_val,y_val,smiles_val = loadInputs_feature_smiles(args,'val')
        feature_test,a_test,y_test,smiles_test = loadInputs_feature_smiles(args,'test')
        args.nclass = y_test.shape[-1]
        names['model' + str(i) ] = GCN(args.natom, args.hidden, args.nclass, args.dropout).to(device)
        optimizer = optim.Adam(names['model' + str(i) ].parameters(), lr=args.lr)
        train_dataset = ToxicDataset(feature_train, a_train, y_train)
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
        val_dataset = ToxicDataset(feature_val, a_val, y_val)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
        test_dataset = ToxicDataset(feature_test, a_test, y_test)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        if args.type == 'regression':
            args.metric = 'RMSE'
            criterion = nn.MSELoss()
            for epoch in range(args.epochs):
                train_loss, train_R2, val_total_loss = training(names['model' + str(i)], train_loader, optimizer,
                                                                criterion, device)
                val_loss, val_RMSE, val_R2, _,_ = evaluate(names['model' + str(i)], val_loader, criterion, device)
                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
            test_loss, test_RMSE, test_R2, _,MAE = evaluate(names['model' + str(i)], test_loader, criterion, device)
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, device)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, device)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, device)
            xgb_train_feature = xgb_train_feature.cpu().numpy()
            xgb_val_feature = xgb_val_feature.cpu().numpy()
            xgb_test_feature = xgb_test_feature.cpu().numpy()
            rmse_df = mechine_regression(xgb_train_feature, y_train, xgb_val_feature, y_val, xgb_test_feature, y_test)
            return rmse_df
        else:
            args.metric = 'AUC'
            criterion = nn.BCEWithLogitsLoss()
            for epoch in range(args.epochs):
                train_loss, val_total_loss = training_classing(names['model' + str(i)], train_loader, optimizer,
                                                               criterion, device)
                val_loss, val_AUC, val_precision, val_recall = evaluate_classion(names['model' + str(i)], val_loader,
                                                                                 criterion, device)

                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
            test_loader_xgb = (torch.from_numpy(np.float32(feature_test)), torch.from_numpy(np.float32(a_test)),
                               torch.from_numpy(np.float32(y_test)))
            test_loss, test_AUC, test_precision, test_recall = evaluate_test_scros(names['model' + str(i)],
                                                                                   test_loader_xgb, criterion, device)
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, device)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, device)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, device)
            xgb_train_feature = xgb_train_feature.cpu().numpy()
            xgb_val_feature = xgb_val_feature.cpu().numpy()
            xgb_test_feature = xgb_test_feature.cpu().numpy()
            auc_df = mechine_classion(xgb_train_feature, y_train, xgb_val_feature, y_val, xgb_test_feature, y_test)
            return auc_df

def save_losscurve(fig,df,args,num):
    epoch=df['epoch']
    train_loss=df['train_loss_list']
    val_loss=df['val_loss']
    plt.plot(epoch,train_loss,color='navy', label='Train Loss')
    plt.plot(epoch,val_loss, color='aqua', label='Val Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title(f'GGNN Loss Curve of {args.protein}')
    plt.legend(loc="upper right")
    save_path=os.path.join(args.save_dir,f'fold_{num}','Loss')
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    plt.savefig(os.path.join(save_path,f'{args.protein}_loss_{num}.jpg')) 

if __name__=="__main__":
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    args = get_argv()
    names = locals()#动态生成局部变量
    args.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    device=args.device
    gcn_scores = []
    #get_scores函数得到gcn分数、xgb_gcn分数，morgan_gcn分数，morgan分数
    gcn_scores = get_scores(gcn_scores,names,args,device)
    writer.close()
    gcn_scores= np.array(gcn_scores)
    gcn_scores = np.nanmean(gcn_scores)  # average score for each model across tasks
    mean_score, std_score = np.nanmean(gcn_scores), np.nanstd(gcn_scores)
    print(f'Overall gcn test {args.metric} = {mean_score:.6f} +/- {std_score:.6f}')

    # xgb_gcn = np.nanmean(xgb_gcn, axis=1)  # average score for each model across tasks
    # xgb_mean_score, xgb_std_score = np.nanmean(xgb_gcn), np.nanstd(xgb_gcn)
    # print(f'Overall xgb_gcn_auc {args.metric} = {xgb_mean_score:.6f} +/- {xgb_std_score:.6f}')

    # morgan_scores = np.nanmean(morgan_scores, axis=1)  # average score for each model across tasks
    # morgan_mean_score, morgan_std_score = np.nanmean(morgan_scores), np.nanstd(morgan_scores)
    # print(f'Overall morgan_test {args.metric} = {morgan_mean_score:.6f} +/- {morgan_std_score:.6f}')

    # gcn_morgan = np.nanmean(gcn_morgan, axis=1)  # average score for each model across tasks
    # gcn_morgan_mean_score, gcn_morgan_std_score = np.nanmean(gcn_morgan), np.nanstd(gcn_morgan)
    # print(f'Overall gcn_morgan_auc {args.metric} = {gcn_morgan_mean_score:.6f} +/- {gcn_morgan_std_score:.6f}')

# if __name__=="__main__":
#     os.environ['CUDA_VISIBLE_DEVICES'] = '0'
#     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#     args = get_argv()

#     gcn_scores = []
#     xgb_scores = []
#     names = locals()
    #df = mechine_scores(gcn_scores,xgb_scores,names,args,device)
    #df.to_csv(args.protein + '_gcn_mechine.csv',index=None)
