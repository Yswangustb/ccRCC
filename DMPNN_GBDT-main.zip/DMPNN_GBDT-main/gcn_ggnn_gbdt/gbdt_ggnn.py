import warnings
warnings.filterwarnings('ignore',category=FutureWarning)
warnings.filterwarnings('ignore',category=UserWarning)
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import argparse

from sklearn import svm
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from torch.utils.data import Dataset
import matplotlib.pyplot as plt
from load_data_batch import loadInputs_train,loadInputs_val,loadInputs_test,ToxicDataset,load_data,ZW6,get_mol,get_morgan_feature,loadInputs_feature_smiles
from sklearn.metrics import precision_recall_curve,mean_squared_error,r2_score,mean_absolute_error
from sklearn.metrics import roc_curve, auc, precision_score, recall_score
import xgboost as xgb
from ggnn_model.ggnn_model import GGNN
import os
from data_deal import decrease_learning_rate
import pandas as pd
from torch.autograd import Variable
from tensorboardX import SummaryWriter
from sklearn.ensemble import GradientBoostingClassifier
from copy import deepcopy
from rdkit.Chem import AllChem
from sklearn.metrics import confusion_matrix,accuracy_score,f1_score
import pickle

def training(model, data,optimizer, criterion, args):
    model.train()
    total_loss = []
    for k in data:
        feature,A,y = k
        if len(y.shape) == 3:
            y = y.squeeze(1)
        model.zero_grad()
        padding = torch.zeros(len(feature), 50, args.hidden - 58)
        init_input = torch.cat((feature, padding), 2)
        init_input,A,feature,y = init_input.cuda(),A.cuda(),feature.cuda(),y.cuda()
        init_input,A,feature = Variable(init_input),Variable(A),Variable(feature)
        target = Variable(y)
        output,_ = model(init_input, feature, A)
        loss = criterion(output, target)

        total_loss.append(loss.item())
        loss.backward()
        # torch.nn.utils.clip_grad_norm_(model.parameters(), args.clip)
        optimizer.step()
        R2 = r2_score(y.cpu().detach().numpy(), output.cpu().detach().numpy())
    model.eval()
    val_total_loss = 0
    with torch.no_grad():
        for k in data:
            feature, A, y = k
            if len(y.shape) == 3:
                y = y.squeeze(1)
            padding = torch.zeros(len(feature), 50, args.hidden - 58)
            init_input = torch.cat((feature, padding), 2)
            init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(
                feature.cuda()), Variable(y.cuda())
            output, _ = model(init_input, feature, A)
            valid_loss = criterion(output, y)
            val_total_loss = val_total_loss+valid_loss
    return (sum(total_loss) / len(total_loss)),R2,val_total_loss

def evaluate(model, data, criterion, args):
    model.eval()
    total_loss = []
    with torch.no_grad():
        for k in data:
            feature, A, y = k
            if len(y.shape) == 3:
                y = y.squeeze(1)
            padding = torch.zeros(len(feature), 50, args.hidden - 58)
            init_input = torch.cat((feature, padding), 2)
            init_input,A ,feature,y= Variable(init_input.cuda()),Variable(A.cuda()),Variable(feature.cuda()),Variable(y.cuda())
            output, feature = model(init_input, feature, A)
            total_loss.append((criterion(output,  y)).item())
            MSE = mean_squared_error(y.cpu().numpy(), output.cpu().numpy())
            RMSE = MSE ** 0.5
            R2 = r2_score(y.cpu().numpy(), output.cpu().numpy())
            mae = mean_absolute_error(y.cpu().numpy(), output.cpu().numpy())
    return (sum(total_loss) / len(total_loss)),RMSE,R2,feature,mae

def evaluate_test_scores(model, data, criterion, args):
    model.eval()
    total_loss = []
    with torch.no_grad():
        feature, A, y = data
        if len(y.shape) == 3:
            y = y.squeeze(1)
        padding = torch.zeros(len(feature), 50, args.hidden - 58)
        init_input = torch.cat((feature, padding), 2)
        init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(feature.cuda()), Variable(
            y.cuda())
        output, feature = model(init_input, feature, A)
        total_loss.append((criterion(output, y)).item())
        MSE = mean_squared_error(y.cpu().numpy(), output.cpu().numpy())
        RMSE = MSE ** 0.5
    return RMSE


def get_feature(model,data, args):
    model.eval()
    i = 0
    with torch.no_grad():
        for k in data:
            feature, A, y = k
            padding = torch.zeros(len(feature), 50, args.hidden - 58)
            init_input = torch.cat((feature, padding), 2)
            init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(feature.cuda()), Variable(y.cuda())
            output, feature = model(init_input, feature, A)
            if i ==0:
                features = feature
            else:
                features = torch.cat((features,feature))
            i = i+1
    return features

def training_classing(model, data,optimizer, criterion, args):
    model.train()
    total_loss = []
    for k in data:
        feature,A,y = k
        model.zero_grad()
        if len(y.shape)==3:
            y = y.squeeze(1)
        padding = torch.zeros(len(feature), 50, args.hidden - 58)
        init_input = torch.cat((feature, padding), 2)
        init_input = init_input.cuda()
        init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(
            feature.cuda()), Variable(y.cuda())
        output, _ = model(init_input, feature, A)
        loss = criterion(output, y)
        total_loss.append(loss.item())
        loss.backward()
        optimizer.step()
    model.eval()
    val_total_loss = 0
    with torch.no_grad():
        for k in data:
            feature, A, y = k
            if len(y.shape) == 3:
                y = y.squeeze(1)
            padding = torch.zeros(len(feature), 50, args.hidden - 58)
            init_input = torch.cat((feature, padding), 2)
            init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(
                feature.cuda()), Variable(y.cuda())
            output, _ = model(init_input, feature, A)
            valid_loss = criterion(output, y)
            val_total_loss = val_total_loss+valid_loss
    return (sum(total_loss) / len(total_loss)),val_total_loss

def evaluate_classion(model, data, criterion, args):
    model.eval()
    total_loss = []
    y_predict = []
    y_test = []
    with torch.no_grad():
        for k in data:
            feature, A, y = k
            if len(y.shape) == 3:
                y = y.squeeze(1)
            padding = torch.zeros(len(feature), 50, args.hidden - 58)
            init_input = torch.cat((feature, padding), 2)
            init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(
                feature.cuda()), Variable(y.cuda())
            output, _ = model(init_input, feature, A)
            total_loss.append((criterion(output,  y)).item())
            output = torch.sigmoid(output)
            output = output.cpu().detach().numpy()
            y = y.cpu().detach().numpy()
            for i in output:
                y_predict.append(i)
            for j in y:
                y_test.append(j)
    y_test = pd.DataFrame(y_test)
    y_predict = pd.DataFrame(y_predict)
    if y_test.shape[1]==1:
        fpr, tpr, threshold = roc_curve(y_test, y_predict)
        AUC = auc(fpr, tpr)
        output_tran = []
        for x in y_predict[0]:
            if x > 0.5:
                output_tran.append(1)
            else:
                output_tran.append(0)
        precision = precision_score(y_test, output_tran)
        recall = recall_score(y_test, output_tran)
    else:
        AUC_all = []
        precision_all = []
        recall_all = []
        for i in range(y_test.shape[1]):
            if max(y_test[i])==0:
                continue
            fpr, tpr, threshold = roc_curve(y_test[i], y_predict[i])
            AUC = auc(fpr, tpr)
            output_tran = []
            for x in y_predict[i]:
                if x > 0.5:
                    output_tran.append(1)
                else:
                    output_tran.append(0)
            precision = precision_score(y_test[i], output_tran)
            recall = recall_score(y_test[i], output_tran)
            AUC_all.append(AUC)
            precision_all.append(precision)
            recall_all.append(recall)
        AUC = np.mean(AUC_all)
        precision = np.mean(precision_all)
        recall = np.mean(recall_all)
    return (sum(total_loss) / len(total_loss)),AUC,precision,recall

def get_evaluate(test_target,pre_pro):
    fpr, tpr, threshold = roc_curve(test_target, pre_pro)
    rocdata={'fpr':fpr,'tpr':tpr,'threshold':threshold}    
    AUC = auc(fpr, tpr)
    pre_pro = [1 if i > 0.5 else 0 for i in pre_pro]
    tn, fp, fn, tp = confusion_matrix(test_target, pre_pro).ravel()
    Sn = tp / (tp + fn)
    Sp = tn / (tn + fp)
    acc = accuracy_score(test_target, pre_pro)
    ner=(Sn+Sp)/2
    f1=f1_score(test_target, pre_pro)
    # mcc=(tp*tn-fp*fn)/(sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
        
    return tn,fp,fn,tp,acc,AUC,ner,f1,rocdata

def evaluate_test_scros(model, data, criterion, args):
    model.eval()
    total_loss = []
    y_predict = []
    y_test = []
    with torch.no_grad():
        feature, A, y = data
        if len(y.shape)==3:
            y = y.squeeze(1)
        padding = torch.zeros(len(feature), 50, args.hidden - 58)
        init_input = torch.cat((feature, padding), 2)
        init_input, A, feature, y = Variable(init_input.cuda()), Variable(A.cuda()), Variable(
            feature.cuda()), Variable(y.cuda())
        output, _ = model(init_input, feature, A)
        total_loss.append((criterion(output,  y)).item())
        output = torch.sigmoid(output)
        output = output.cpu().detach().numpy()
        y = y.cpu().detach().numpy()
        for i in output:
            y_predict.append(i)
        for j in y:
            y_test.append(j)
    y_test = pd.DataFrame(y_test)
    y_predict = pd.DataFrame(y_predict)
    if y_test.shape[1]==1:
        fpr, tpr, threshold = roc_curve(y_test, y_predict)
        AUC = auc(fpr, tpr)
        ####在这块返回roc曲线图
            #画出此类ROC曲线
        output_tran = []
        for x in y_predict[0]:
            if x > 0.5:
                output_tran.append(1)
            else:
                output_tran.append(0)
        precision = precision_score(y_test, output_tran)
        recall = recall_score(y_test, output_tran)
    else:
        AUC_all = []
        precision_all = []
        recall_all = []
        for i in range(y_test.shape[1]):
            if max(y_test[i])==0 or max(y_predict[i])==0:
                continue
            fpr, tpr, threshold = roc_curve(y_test[i], y_predict[i])
            AUC = auc(fpr, tpr)
            output_tran = []
            for x in y_predict[i]:
                if x > 0.5:
                    output_tran.append(1)
                else:
                    output_tran.append(0)
            precision = precision_score(y_test[i], output_tran)
            recall = recall_score(y_test[i], output_tran)
            if args.folder == "benchmark_molnet/molnet_random_pcba_c" or args.folder == "benchmark_molnet/molnet_random_muv_c":
                precision, recall, _ = precision_recall_curve(y_test[i], output_tran)
                AUC = auc(recall, precision)
            AUC_all.append(AUC)
            precision_all.append(precision)
            recall_all.append(recall)
        AUC = np.mean(AUC_all)
        precision = np.mean(precision_all)
        recall = np.mean(recall_all)
    return (sum(total_loss) / len(total_loss)),AUC,precision,recall,y_predict

def xgb_regression(X_train,y_train,X_val, y_val,X_test,y_test):
    from xgboost.sklearn import XGBRegressor
    if y_test.shape[-1]==1:
        model = XGBRegressor(
            learn_rate=0.1,
            max_depth=4,#4
            min_child_weight=10,
            gamma=1,#1
            subsample=0.8,
            colsample_bytree=0.8,
            reg_alpha=0.8,
            objective='reg:linear',
            n_estimators=2000,
            tree_method = 'gpu_hist',
            n_gpus = -1
        )
        model.fit(X_train, y_train,eval_set=[(X_val, y_val)], eval_metric='rmse',
                  early_stopping_rounds=300)
        y_pred = model.predict(X_test)
        y_test = y_test.astype('float')
        MSE = mean_squared_error(y_test,y_pred)
        RMSE = MSE ** 0.5
        mae = mean_absolute_error(y_test, y_pred)
        if args.folder == "benchmark_molnet/molnet_random_qm7_r":
            return mae
        else:
            return RMSE
    else:
        RMSEs = []
        if len(y_train.shape)==3:
            y_train = [x[0] for x in y_train]
            y_val = [x[0] for x in y_val]
            y_test = [x[0] for x in y_test]
            y_train = pd.DataFrame(y_train)
            y_val = pd.DataFrame(y_val)
            y_test = pd.DataFrame(y_test)
        for i in range(y_test.shape[1]):
            if float(max(y_val[i])) == 0 or float(max(y_train[i])) == 0 or float(max(y_test[i])) == 0:
                continue
            model = XGBRegressor(
                learn_rate=0.1,
                max_depth=4,  # 4
                min_child_weight=10,
                gamma=1,  # 1
                subsample=0.8,
                colsample_bytree=0.8,
                reg_alpha=0.8,
                objective='reg:linear',
                n_estimators=2000,
                tree_method='gpu_hist',
                n_gpus=-1
            )
            model.fit(X_train, [float(k) for k in y_train[i]], eval_set=[(X_val, [float(k) for k in y_val[i]])], eval_metric='rmse',
                      early_stopping_rounds=300)
            y_pred = model.predict(X_test)
            y_test = y_test.astype('float')
            MSE = mean_squared_error(y_test[i], y_pred)
            RMSE = MSE ** 0.5
            mae = mean_absolute_error(y_test[i], y_pred)
            if args.folder == "benchmark_molnet/molnet_random_qm8_r" or args.folder == "benchmark_molnet/molnet_random_qm9_r":
                RMSEs.append(mae)
            else:
                RMSEs.append(RMSE)
        return np.mean(RMSEs)

def mechine_regression(X_train,y_train,X_val, y_val,X_test,y_test):
    scores = []
    if y_test.shape[-1]==1:
        rf = RandomForestRegressor()
        rf.fit(X_train, y_train)
        y_pred = rf.predict(X_test)
        y_test = y_test.astype('float')
        MSE = mean_squared_error(y_test,y_pred)
        RMSE = MSE ** 0.5
        type = 'GGNN+rf'
        scores.append([type,RMSE])
        clf = svm.SVR(C=0.8, cache_size=200, kernel='rbf', degree=3, epsilon=0.2)
        clf.fit(X_train, y_train)
        y_pre = clf.predict(X_test)
        MSE = mean_squared_error(y_test, y_pre)
        RMSE = MSE ** 0.5
        type = 'GGNN+svm'
        scores.append([type, RMSE])
        knn = KNeighborsRegressor(n_neighbors=5)
        knn.fit(X_train, y_train)
        y_pre = knn.predict(X_test)
        MSE = mean_squared_error(y_test, y_pre)
        RMSE = MSE ** 0.5
        type = 'GGNN+knn'
        scores.append([type, RMSE])
        scores_df = pd.DataFrame(scores)
        return scores_df
    else:
        if len(y_train.shape)==3:
            y_train = [x[0] for x in y_train]
            y_val = [x[0] for x in y_val]
            y_test = [x[0] for x in y_test]
            y_train = pd.DataFrame(y_train)
            y_val = pd.DataFrame(y_val)
            y_test = pd.DataFrame(y_test)
        rf_rmse = []
        svm_rmse = []
        knn_rmse = []
        for i in range(y_test.shape[1]):
            if float(max(y_val[i])) == 0 or float(max(y_train[i])) == 0 or float(max(y_test[i])) == 0:
                continue
            rf = RandomForestRegressor()
            rf.fit(X_train, y_train[i])
            y_pred = rf.predict(X_test)
            y_test = y_test[i].astype('float')
            MSE = mean_squared_error(y_test[i], y_pred)
            RMSE = MSE ** 0.5
            rf_rmse.append(RMSE)
        type = 'GGNN+rf'
        scores.append([type, np.mean(rf_rmse)])
        for i in range(y_test.shape[1]):
            clf = svm.SVR(C=0.8, cache_size=200, kernel='rbf', degree=3, epsilon=0.2)
            clf.fit(X_train, y_train[i])
            y_pre = clf.predict(X_test)
            MSE = mean_squared_error(y_test[i], y_pre)
            RMSE = MSE ** 0.5
            type = 'GGNN+svm'
            scores.append([type, RMSE])
            knn = KNeighborsRegressor(n_neighbors=5)
            knn.fit(X_train, y_train[i])
            y_pre = knn.predict(X_test)
            MSE = mean_squared_error(y_test[i], y_pre)
            RMSE = MSE ** 0.5
            svm_rmse.append([type, RMSE])
        type = 'GGNN+svm'
        scores.append([type, np.mean(svm_rmse)])
        for i in range(y_test.shape[1]):
            knn = KNeighborsRegressor(n_neighbors=5)
            knn.fit(X_train, y_train[i])
            y_pre = knn.predict(X_test)
            MSE = mean_squared_error(y_test[i], y_pre)
            RMSE = MSE ** 0.5
            knn_rmse.append(RMSE)
        type = 'GGNN+knn'
        scores.append([type, np.mean(knn_rmse)])
        scores_df = pd.DataFrame(scores)
        return scores_df

def mechine_classion(X_train,y_train,X_val, y_val,X_test,y_test,train_gcn_mor_feature,val_gcn_mor_feature,test_gcn_mor_feature,pkl_path,args,scores_df):
    if y_test.shape[-1]==1:
        # scores = []
        # rf = RandomForestClassifier()
        # rf.fit(X_train, y_train)  # 使用训练集对测试集进行训练
        # y_pre = rf.predict(X_test)
        # fpr, tpr, threshold = roc_curve(y_test, y_pre)
        # AUC = auc(fpr, tpr)
        # type = 'ggnn+rf'
        # scores.append([type, AUC])
        for n_estimator in [10,50,100,300,700,1000]:
            for mmax_depth in [2,4,6,8,10]:
                for max_feature in ['sqrt','log2']:
                    for mcriterion in ['gini','entropy']:
                        rf1=RandomForestClassifier(n_estimators=n_estimator,max_depth=mmax_depth,max_features=max_feature,criterion=mcriterion,class_weight='balanced',n_jobs=-1)
                        rf1.fit(X_train, y_train)  # 使用训练集对测试集进行训练
                        pre_pro = rf1.predict_proba(X_test)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+rf'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'max_depth':mmax_depth,'max_features':max_feature,'criterion':mcriterion,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_maxdepth{mmax_depth}_maxfeature{max_feature}_criterion{mcriterion}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
                        
                        rf2=RandomForestClassifier(n_estimators=n_estimator,max_depth=mmax_depth,max_features=max_feature,criterion=mcriterion,class_weight='balanced',n_jobs=-1)
                        rf2.fit(train_gcn_mor_feature,y_train)  # 使用训练集对测试集进行训练
                        pre_pro = rf2.predict_proba(test_gcn_mor_feature)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+moragn+rf'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'max_depth':mmax_depth,'max_features':max_feature,'criterion':mcriterion,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_maxdepth{mmax_depth}_maxfeature{max_feature}_criterion{mcriterion}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
            
        for n_estimator in [10,50,100,300,700,1000]:
            for mmin_samples_split in [2,3,4,5]:
                for mmax_depth in [2,4,6,8,10]:
                    for max_feature in ['sqrt','log2']:
                        clf1=GradientBoostingClassifier(n_estimators=n_estimator,min_samples_split=mmin_samples_split,max_depth=mmax_depth,max_features=max_feature)
                        clf1.fit(X_train,y_train)
                        pre_pro = clf1.predict_proba(X_test)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+GBDT'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'min_samples_split':mmin_samples_split,'max_depth':mmax_depth,'max_features':max_feature,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_minsample{mmin_samples_split}_maxdepth{mmax_depth}_maxfeature{max_feature}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
                        
                        clf2=GradientBoostingClassifier(n_estimators=n_estimator,min_samples_split=mmin_samples_split,max_depth=mmax_depth,max_features=max_feature)
                        clf2.fit(train_gcn_mor_feature, y_train)
                        pre_pro = clf2.predict_proba(test_gcn_mor_feature)[:, 1]
                        tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,pre_pro)
                        ml_type = 'ggnn+morgan+GBDT'
                        model_param={'type':ml_type,'n_estimators':n_estimator,'min_samples_split':mmin_samples_split,'max_depth':mmax_depth,'max_features':max_feature,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
                        with open (os.path.join(pkl_path,f'{ml_type}_estimator{n_estimator}_minsample{mmin_samples_split}_maxdepth{mmax_depth}_maxfeature{max_feature}.pkl'),'wb') as f:
                            pickle.dump([rocdata,model_param],f)
                        scores_df=scores_df.append(model_param,ignore_index=True)
        
        scores_df=scores_df.where((scores_df.notna()),'None')
        # clf = svm.SVC(C=1, kernel='rbf', degree=3, gamma='auto',
        #               coef0=0.0, shrinking=True, probability=False,
        #               tol=1e-3, cache_size=200, class_weight=None,
        #               verbose=False, max_iter=-1, decision_function_shape='ovr',
        #               random_state=None)
        # clf.fit(X_train, y_train)
        # y_pre = clf.predict(X_test)
        # fpr, tpr, threshold = roc_curve(y_test, y_pre)
        # AUC = auc(fpr, tpr)
        # type = 'ggnn+svm'
        # scores.append([type, AUC])
        # clf = KNeighborsClassifier(n_neighbors=5, weights='uniform')
        # clf.fit(X_train, y_train)
        # y_pre = clf.predict(X_test)
        # fpr, tpr, threshold = roc_curve(y_test, y_pre)
        # AUC = auc(fpr, tpr)
        # type = 'ggnn+rnn'
        # scores.append([type, AUC])
        # scores_df = pd.DataFrame(scores)
        return scores_df
    else:
        rf_auc = []
        svm_auc = []
        knn_auc = []
        scores = []
        if len(y_train.shape)==3:
            y_train = [x[0] for x in y_train]
            y_val = [x[0] for x in y_val]
            y_test = [x[0] for x in y_test]
            y_train = pd.DataFrame(y_train)
            y_val = pd.DataFrame(y_val)
            y_test = pd.DataFrame(y_test)
        for i in range(y_test.shape[1]):
            if float(max(y_train[i])) == 0 or float(max(y_test[i])) == 0 or float(min(y_test[i])) == 1:
                continue
            rf = RandomForestClassifier()
            rf.fit(X_train, y_train[i])  # 使用训练集对测试集进行训练
            y_pre = rf.predict(X_test)
            if float(max(y_pre)) == 0 or float(min(y_pre)) == 1:
                continue
            fpr, tpr, threshold = roc_curve([float(j) for j in y_test[i]], [float(k) for k in y_pre])
            AUC = auc(fpr, tpr)
            if AUC>0:
                rf_auc.append(AUC)
        type = 'ggnn+rf'
        scores.append([type, np.mean(rf_auc)])
        for i in range(y_test.shape[1]):
            clf = svm.SVC(C=1, kernel='rbf', degree=3, gamma='auto',
                          coef0=0.0, shrinking=True, probability=False,
                          tol=1e-3, cache_size=200, class_weight=None,
                          verbose=False, max_iter=-1, decision_function_shape='ovr',
                          random_state=None)
            clf.fit(X_train, y_train[i])
            y_pre = clf.predict(X_test)
            fpr, tpr, threshold = roc_curve([float(j) for j in y_test[i]], [float(k) for k in y_pre])
            AUC = auc(fpr, tpr)
            if AUC>0:
                svm_auc.append(AUC)
        type = 'ggnn+svm'
        scores.append([type, np.mean(svm_auc)])
        for i in range(y_test.shape[1]):
            clf = KNeighborsClassifier(n_neighbors=5, weights='uniform')
            clf.fit(X_train, y_train[i])
            y_pre = clf.predict(X_test)
            fpr, tpr, threshold = roc_curve([float(j) for j in y_test[i]], [float(k) for k in y_pre])
            AUC = auc(fpr, tpr)
            if AUC>0:
                knn_auc.append(AUC)
        type = 'ggnn+knn'
        scores.append([type, np.mean(knn_auc)])
        scores_df = pd.DataFrame(scores)
        return scores_df

def xgboost_classion(X_train,y_train,X_val, y_val,X_test,y_test,i):
    if y_test.shape[-1]==1:
        #得到模型
        xgb_gbc = xgb.XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
               colsample_bytree=1, gamma=1, learning_rate=0.1, max_delta_step=0,
               max_depth=4, min_child_weight=8, n_estimators=2000,
               n_jobs=1, nthread=None, objective='binary:logistic', random_state=0,
               reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=None,
               silent=True, subsample=0.8,tree_method='gpu_hist',n_gpus=-1)
        #代入数据到模型
        xgb_gbc.fit(X_train,y_train,eval_set = [(X_val,y_val)],eval_metric = 'auc',early_stopping_rounds=300)
        #测试集效果
        pre_pro = xgb_gbc.predict_proba(X_test)[:,1]
        fpr,tpr,thresholds = roc_curve([float(i) for i in y_test],pre_pro)
        AUC = auc(fpr,tpr)
        if args.folder == "benchmark_molnet/molnet_random_pcba_c" or args.folder == "benchmark_molnet/molnet_random_muv_c":
            precision, recall, _ = precision_recall_curve(y_test, pre_pro)
            AUC = auc(recall, precision)
        return fpr,tpr,thresholds,AUC
    else:
        aucs = []
        if len(y_train.shape)==3:
            y_train = [x[0] for x in y_train]
            y_val = [x[0] for x in y_val]
            y_test = [x[0] for x in y_test]
            y_train = pd.DataFrame(y_train)
            y_val = pd.DataFrame(y_val)
            y_test = pd.DataFrame(y_test)
        for i in range(y_test.shape[1]):
            if  float(max(y_train[i])) == 0 or float(max(y_test[i])) == 0:
                continue
            xgb_gbc = xgb.XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
                                        colsample_bytree=1, gamma=1, learning_rate=0.1, max_delta_step=0,
                                        max_depth=4, min_child_weight=8, n_estimators=2000,
                                        n_jobs=1, nthread=None, objective='binary:logistic', random_state=0,
                                        reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=None,
                                        silent=True, subsample=0.8, tree_method='gpu_hist', n_gpus=-1)
            xgb_gbc.fit(X_train, y_train[i],early_stopping_rounds=300)
            pre_pro = xgb_gbc.predict_proba(X_test)[:, 1]
            fpr, tpr, thresholds = roc_curve([float(j) for j in y_test[i]], pre_pro)
            AUC = auc(fpr, tpr)
            if args.folder == "benchmark_molnet/molnet_random_pcba_c" or args.folder == "benchmark_molnet/molnet_random_muv_c":
                precision, recall, _ = precision_recall_curve([float(j) for j in y_test[i]], pre_pro)
                AUC = auc(recall, precision)
            aucs.append(AUC)
        return fpr,tpr,thresholds,np.mean(aucs)

def get_argv():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=200,
                        help='Number of epochs to train.')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='Initial learning rate.')
    # parser.add_argument('--folder', type=str, default="benchmark_molnet/molnet_random_CCR5_c")
    parser.add_argument('--hidden', type=int, default=512,
                        help='Number of hidden units.')
    parser.add_argument('--dropout', type=float, default=0.5,
                        help='Dropout rate (1 - keep probability).')
    parser.add_argument('--save_dir', type=str, default="loss")
    parser.add_argument('--batch_size', type=float, default=128)
    parser.add_argument('--natom', type=float, default=50)
    parser.add_argument('--nclass', type=float, default=1)
    parser.add_argument('--protein',type=str,default='CCR5')
    parser.add_argument('--type', type=str, default="classification")
    args = parser.parse_args()
    return args



def get_scores(gcn_scores,names,args,device):
    '''
    给出ggnn
    ggnn+rf/GBDT
    ggnn+morgan+rf/GBDT
    '''
    #五折交叉验证
    scores_df=pd.DataFrame()
    for i in range(5):
        if not os.path.exists(os.path.join(args.save_dir,f'fold_{i}','model_0')):
            os.makedirs(os.path.join(args.save_dir,f'fold_{i}','model_0'))
        writer = SummaryWriter(log_dir=os.path.join(args.save_dir,f'fold_{i}','model_0'))
        train_loss_list = []
        val_loss_list = []
        epoch_number = []
        #加载本折数据+参数
        args.folder=os.path.join('benchmark_molnet',f'molnet_random_{args.protein}_c')
        args.dataset = args.folder + '/seed' + str(i )
        train_smiles,val_smiles,test_smiles=load_data(args)
        #feature_train,a_train,y_train,train_smiles = loadInputs_feature_smiles(args,'train')
        #feature_val,a_val,y_val,val_smiles = loadInputs_feature_smiles(args,'val')
        #feature_test,a_test,y_test,test_smiles = loadInputs_feature_smiles(args,'test')
        feature_train, a_train, y_train = loadInputs_train(args)
        feature_val, a_val, y_val = loadInputs_val(args)
        feature_test, a_test, y_test = loadInputs_test(args)
        print(f'train的shape{feature_train.shape},{a_train.shape},{y_train.shape}')
        print(f'val的shape{feature_val.shape},{a_val.shape},{y_val.shape}')
        print(f'test的shape{feature_test.shape},{a_test.shape},{y_test.shape}')

        args.nclass = y_test.shape[-1]
        #GGNN模型创建/优化器
        names['model' + str(i)] = GGNN(args.natom, args.hidden, args.nclass, args.dropout).to(device)
        optimizer = optim.Adam(names['model' + str(i)].parameters(), lr=args.lr)
        #训练/验证/测试数据集生成迭代器
        train_dataset = ToxicDataset(feature_train, a_train, y_train)
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
        val_dataset = ToxicDataset(feature_val, a_val, y_val)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
        test_dataset = ToxicDataset(feature_test, a_test, y_test)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        if args.type == 'regression':
            args.metric = 'RMSE'
            criterion = nn.MSELoss()
            for epoch in range(args.epochs):
                train_loss, train_R2, val_total_loss = training(names['model' + str(i)], train_loader, optimizer,
                                                                criterion, args)
                val_loss, val_RMSE, val_R2, _,_ = evaluate(names['model' + str(i)], val_loader, criterion, args)
                print(f'\tTrain Loss: {train_loss:.3f}%')
                print(f'\t Val. RMSE: {val_RMSE:.3f}')
                writer.add_scalar('Train/Loss', train_loss, epoch)
                writer.add_scalar('val/Loss', val_loss, epoch)
                train_loss_list.append(train_loss)
                val_loss_list.append(val_loss)
                epoch_number.append(epoch)
                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
            test_loss, test_RMSE, test_R2, _,MAE = evaluate(names['model' + str(i)], test_loader, criterion, args)
            print(f'\t test. RMSE: {test_RMSE:.3f}')
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, args)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, args)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, args)
            xgb_train_feature = xgb_train_feature.cpu().numpy()
            xgb_val_feature = xgb_val_feature.cpu().numpy()
            xgb_test_feature = xgb_test_feature.cpu().numpy()
            xgb_RMSE = xgb_regression(xgb_train_feature, y_train, xgb_val_feature, y_val, xgb_test_feature, y_test)
            if args.folder =="benchmark_molnet/molnet_random_qm7_r":
                gcn_scores.append([MAE])
            else:
                gcn_scores.append([test_RMSE])
            xgb_scores.append([xgb_RMSE])
        else:
            args.metric = 'AUC'
            criterion = nn.BCEWithLogitsLoss()
            #得到损失曲线图
            best_score = 0 
            best_epoch = 0
            for epoch in range(args.epochs):
                #训练集进行训练
                train_loss, val_total_loss = training_classing(names['model' + str(i)], train_loader, optimizer,
                                                               criterion, args)
                #验证集进行验证
                val_loss, val_AUC, val_precision, val_recall = evaluate_classion(names['model' + str(i)], val_loader,
                                                                                criterion, args)
                #输出每一epoch训练验证结果
                print(f'\t Epoch:{epoch+1}__Train Loss: {train_loss:.3f}')
                print(f'\tVal AUC: {val_AUC:.3f}')
                print(f'\tVal. precision: {val_precision:.3f}')
                #loss曲线加入tensorboard
                writer.add_scalar('Train/Loss', train_loss, epoch)
                writer.add_scalar('val/Loss', val_loss, epoch)
                train_loss_list.append(train_loss)
                val_loss_list.append(val_loss)
                epoch_number.append(epoch)
                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
                # Average validation score
                # Save model checkpoint if improved validation score，如果提升验证集性能则保存model
                if val_AUC > best_score:
                    best_score, best_epoch = val_AUC, epoch
                    best_model_state = deepcopy(names['model' + str(i)].state_dict()) 
                    model_save_path=os.path.join(args.save_dir,f'fold_{i}','model_0', 'model.pt')
                    torch.save(best_model_state, model_save_path)
                    
            #绘制GGNN损失曲线
            df = pd.DataFrame({'epoch': epoch_number, 'train_loss_list': train_loss_list, 'val_loss': val_loss_list})
            if not os.path.exists(os.path.join(args.save_dir,f'fold_{i}','Loss')):
                os.makedirs(os.path.join(args.save_dir,f'fold_{i}','Loss'))
            df.to_csv(os.path.join(args.save_dir,f'fold_{i}','Loss',args.protein+f'_loss_{i}.csv'),index=None)
            fig1=plt.figure()
            save_losscurve(fig1,df,args,i)
            #测试集迭代器
            test_loader_xgb = (torch.from_numpy(np.float32(feature_test)), torch.from_numpy(np.float32(a_test)),
                               torch.from_numpy(np.float32(y_test)))
            
            #预测的时候加载在验证集上表现最好的模型
            loaded_paras = torch.load(model_save_path)
            names['model' + str(i)].load_state_dict(loaded_paras)  # 用本地已有模型来重新初始化网络权重参数
            #仅用GGNN得到的测试集指标
            test_loss,test_AUC, test_precision, test_recall ,y_predict= evaluate_test_scros(names['model' + str(i)],
                                                                                   test_loader_xgb, criterion, args)
            print(type(y_test),type(y_predict))
            print(y_test)
            print(y_test[0])
            tn,fp,fn,tp,acc,AUC,ner,f1,rocdata=get_evaluate(y_test,y_predict[0])
            ml_type = 'ggnn'
            model_param={'type':ml_type,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
            pkl_path=os.path.join(args.save_dir,f'fold_{i}','model_0','test_preds')
            if not os.path.exists(pkl_path):
                os.makedirs(os.path.join(pkl_path))
            with open (os.path.join(pkl_path,f'{ml_type}.pkl'),'wb') as f:
                pickle.dump([rocdata,model_param],f)
            scores_df=scores_df.append(model_param,ignore_index=True)
                
            
            
            # fpr, tpr, threshold = roc_curve(test_target, [i[0] for i in test_preds])
            # AUC = auc(fpr, tpr)
            # pre_pro = [1 if i > 0.5 else 0 for i in [i[0] for i in test_preds]]
            # tn, fp, fn, tp = confusion_matrix(test_target, pre_pro).ravel()
            # Sn = tp / (tp + fn)
            # Sp = tn / (tn + fp)
            # acc = accuracy_score(test_target, pre_pro)
            # ner=(Sn+Sp)/2
            # f1=f1_score(test_target, pre_pro)
            # # mcc=(tp*tn-fp*fn)/(sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
            # rocdata={'fpr':fpr,'tpr':tpr,'threshold':threshold}
            # xgb_type='dmpnn'
            # model_param={'type':xgb_type,'TN':tn,'FP':fp,'FN':fn,'TP':tp,'ACC':acc,'AUC':AUC,'NER':ner,'F1':f1}
            # #将fpr,tpr,threshold及参数信息存为pkl

            # with open (os.path.join(pkl_path,'dmpnn.pkl'),'wb') as f:
            #     pickle.dump([rocdata,model_param],f)
            # scores_df=scores_df.append(model_param,ignore_index=True)
            
            
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            #得到GGNN输出的训练集、验证集、测试集的特征
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, args)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, args)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, args)
            xgb_train_feature = pd.DataFrame(xgb_train_feature.cpu().numpy())
            xgb_val_feature = pd.DataFrame(xgb_val_feature.cpu().numpy())
            xgb_test_feature =pd.DataFrame(xgb_test_feature.cpu().numpy())
            #得到morgan特征
            train_morgan_feature = get_morgan_feature(train_smiles)
            val_morgan_feature = get_morgan_feature(val_smiles)
            test_morgan_feature = get_morgan_feature(test_smiles)
            #拼接morgan特征与ggnn特征
            train_gcn_mor_feature = pd.concat([xgb_train_feature, train_morgan_feature], axis=1)
            val_gcn_mor_feature = pd.concat([xgb_val_feature, val_morgan_feature], axis=1)
            test_gcn_mor_feature = pd.concat([xgb_test_feature, test_morgan_feature], axis=1)
            train_gcn_mor_feature.columns = val_gcn_mor_feature.columns = test_gcn_mor_feature.columns = range(train_gcn_mor_feature.shape[1])  
            
            ####导出GGNN+GBDT/RF的结果
            scores_df= mechine_classion(xgb_train_feature, y_train, xgb_val_feature, y_val,xgb_test_feature, y_test,train_gcn_mor_feature,val_gcn_mor_feature,test_gcn_mor_feature,pkl_path,args,scores_df)
            # xgboost_classion(xgb_train_feature, y_train, xgb_val_feature, y_val,xgb_test_feature, y_test,i)
            # #roc曲线图
            # fig2=plt.figure()
            # save_roccurve(fig2,fpr,tpr,thresholds,xgb_auc,i,args)
            gcn_scores.append([test_AUC])
            # xgb_scores.append([xgb_auc])
    scores_df.to_csv(os.path.join(args.save_dir,f'{args.protein}_mechine_scores.csv'))

    return gcn_scores


def mechine_scores(gcn_scores,xgb_scores,names,args,device):
    for i in range(5):
        args.dataset = args.folder + '/seed' + str(i )
        load_data(args)
        feature_train, a_train, y_train = loadInputs_train(args)
        feature_val, a_val, y_val = loadInputs_val(args)
        feature_test, a_test, y_test = loadInputs_test(args)
        args.nclass = y_test.shape[-1]
        #建立GGNN模型
        names['model' + str(i)] = GGNN(args.natom, args.hidden, args.nclass, args.dropout).to(device)
        optimizer = optim.Adam(names['model' + str(i)].parameters(), lr=args.lr)
        #建立训练集、验证集、测试集及其迭代器
        train_dataset = ToxicDataset(feature_train, a_train, y_train)
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
        val_dataset = ToxicDataset(feature_val, a_val, y_val)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
        test_dataset = ToxicDataset(feature_test, a_test, y_test)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        if args.type == 'regression':
            args.metric = 'RMSE'
            criterion = nn.MSELoss()
            for epoch in range(args.epochs):
                train_loss, train_R2, val_total_loss = training(names['model' + str(i)], train_loader, optimizer,
                                                                criterion, args)
                val_loss, val_RMSE, val_R2, _,_ = evaluate(names['model' + str(i)], val_loader, criterion, args)
                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
            test_loss, test_RMSE, test_R2, _,MAE = evaluate(names['model' + str(i)], test_loader, criterion, args)
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, args)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, args)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, args)
            xgb_train_feature = xgb_train_feature.cpu().numpy()
            xgb_val_feature = xgb_val_feature.cpu().numpy()
            xgb_test_feature = xgb_test_feature.cpu().numpy()
            rmse_df = mechine_regression(xgb_train_feature, y_train, xgb_val_feature, y_val, xgb_test_feature, y_test)
            return rmse_df
        else:
            args.metric = 'AUC'
            criterion = nn.BCEWithLogitsLoss()
            #GGNN模型进行训练及验证集
            for epoch in range(args.epochs):
                train_loss, val_total_loss = training_classing(names['model' + str(i)], train_loader, optimizer,
                                                               criterion, args)
                val_loss, val_AUC, val_precision, val_recall = evaluate_classion(names['model' + str(i)], val_loader,
                                                                                 criterion, args)

                if epoch % 4 == 0 and epoch != 0:
                    decrease_learning_rate(optimizer, decrease_by=0.001)
            test_loader_xgb = (torch.from_numpy(np.float32(feature_test)), torch.from_numpy(np.float32(a_test)),
                               torch.from_numpy(np.float32(y_test)))
            #GGNN模型在测试集上表现
            test_loss, test_AUC, test_precision, test_recall = evaluate_test_scros(names['model' + str(i)],
                                                                                   test_loader_xgb, criterion, args)
            train_dataset = ToxicDataset(feature_train, a_train, y_train)
            train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False)
            xgb_train_feature = get_feature(names['model' + str(i)], train_loader, args)
            xgb_val_feature = get_feature(names['model' + str(i)], val_loader, args)
            xgb_test_feature = get_feature(names['model' + str(i)], test_loader, args)
            xgb_train_feature = xgb_train_feature.cpu().numpy()
            xgb_val_feature = xgb_val_feature.cpu().numpy()
            xgb_test_feature = xgb_test_feature.cpu().numpy()
            #机器学习
            auc_df = mechine_classion(xgb_train_feature, y_train, xgb_val_feature, y_val, xgb_test_feature, y_test)
            return auc_df
#绘制roc曲线并保存
def save_roccurve(fig,fpr,tpr,thresholds,xgb_auc,num,args):
    optimal_th,optimal_point=Find_optimal_cutoff(tpr,fpr,thresholds)
        
    #画出此类ROC曲线
    plt.plot(fpr, tpr, color='aqua',
             lw=2, label='%s(area = %0.10f,optimal threshold=%0.2f)' % (args.protein,xgb_auc,optimal_th))
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.plot(optimal_point[0],optimal_point[1],marker='o',color='r')
    # plt.text(optimal_point[0][0],optimal_point[0][1],f'Threshold:{optimal_th:.2f}')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    if not os.path.exists('result_figure/roc'):
        os.makedirs('result_figure/roc')
    plt.savefig(f'result_figure/roc/roc_fig_{args.protein}_{num}.jpg')
    

def Find_optimal_cutoff(TPR,FPR,threshold):
    y=TPR-FPR
    Youden_index=np.argmax(y)
    optimal_threshold=threshold[Youden_index]
    point=[FPR[Youden_index],TPR[Youden_index]]
    return optimal_threshold,point

#绘制损失曲线并保存
def save_losscurve(fig,df,args,num):
    epoch=df['epoch']
    train_loss=df['train_loss_list']
    val_loss=df['val_loss']
    plt.plot(epoch,train_loss,color='navy', label='Train Loss')
    plt.plot(epoch,val_loss, color='aqua', label='Val Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title(f'GGNN Loss Curve of {args.protein}')
    plt.legend(loc="upper right")
    save_path=os.path.join(args.save_dir,f'fold_{num}','Loss')
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    plt.savefig(os.path.join(save_path,f'{args.protein}_loss_{num}.jpg'))    
    

if __name__=="__main__":
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    args = get_argv()

    gcn_scores = []
    #xgb_scores = []
    names = locals()#动态生成局部变量
    #得到df,fpr,tpr,xgb_auc
    gcn_scores= get_scores(gcn_scores,names,args,device)
    print(gcn_scores)
    #print(xgb_scores)
    gcn_scores = np.array(gcn_scores)
    #xgb_scores = np.array(xgb_scores)
    gcn_scores = np.nanmean(gcn_scores)  # average score for each model across tasks
    mean_score, std_score = np.nanmean(gcn_scores), np.nanstd(gcn_scores)
    print(f'Overall test {args.metric} = {mean_score:.6f} +/- {std_score:.6f}')

    #xgb_scores = np.nanmean(xgb_scores)  # average score for each model across tasks
    #xgb_mean_score, xgb_std_score = np.nanmean(xgb_scores), np.nanstd(xgb_scores)
    #print(f'Overall xgb_test {args.metric} = {xgb_mean_score:.6f} +/- {xgb_std_score:.6f}')

    
    


#if __name__=="__main__":
    # os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # args = get_argv()

    # gcn_scores = []
    # xgb_scores = []
    # names = locals()
    #机器学习
    # df2 = mechine_scores(gcn_scores,xgb_scores,names,args,device)
    # #df2.to_csv(args.protein + '_mechine.csv',index=None)



