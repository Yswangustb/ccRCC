## Installation

Create a conda environment :
```shell script
conda env create -f environment.yml python==2.7
```
```shell script
conda activate chemprop
```
## train--dmpnn_gbdt
```shell script
nohup python train.py --protein CHEMBL243 --dataset_type classification --save_dir delaney_CHEMBL243_c --epoch 200 > out1 2>&1 &
```
## train--gcn_gbdt
```shell script
nohup python gcn_xgb_morgan.py --protein CHEMBL243 --type classification --save_dir delaney_CHEMBL243_gcn_c --epochs 200 > out21 2>&1 &
```
## train--ggnn_gbdt
```shell script
nohup python xgb_ggnn.py --protein CHEMBL243 --type classification --save_dir delaney_CHEMBL243_c --epochs 200 > out1 2>&1 &

```


